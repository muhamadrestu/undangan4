function closeNav() {
  document.getElementById("myNav").style.display = "none";
}
